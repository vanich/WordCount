

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Collections;


import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.Mongo;
import com.mongodb.MongoClient;
import com.mongodb.MongoCredential;
//import com.mongodb.async.client.MongoDatabase;

public class WordCount {
	public static void main( String args[] ) throws FileNotFoundException {

		
		if(args.length == 0)
		{
			System.out.println("File Name is required");
		}
		else
		{
			File f= new File(args[0].toString()); 
			System.out.println("File Name : " +args[0].toString());
			ArrayList<String> words = new ArrayList<String>();
			HashMap<String, Integer> uwords = new HashMap<String, Integer>();
			Scanner in = new Scanner(f);
			int i=0;
			while(in.hasNext())
			{
				String s=in.next();
				String removeDot = s.replaceAll("[.]", ""); //replaced dot with empty char
				words.add(removeDot);
			}
			System.out.println("Number of words : "+words.size());
			Iterator itr = words.iterator();
			while(itr.hasNext())
			{
				i=0;
				String s = (String)itr.next();
				for(String str : words)
				{
					if(s.equals(str))
					{
						i++;
					} 
					
				}
				
				uwords.put(s,i);
				
			}
			System.out.println("Number of unique words......"+uwords.size());
			for(Map.Entry entry : uwords.entrySet()) {
				System.out.println(entry.getKey() +" : " + entry.getValue());
			}
			 
			//MongoDB - start
			
			Mongo mongo = new Mongo("localhost", 27017); 
			DB db =   mongo.getDB("WordCounts"); 
			DBCollection collection = db.getCollection("WC");
			//collection.insert(new BasicDBObject(uwords));  // Inserting all Map Entries as one document
	
			HashMap<String, Object> resultWords = new HashMap<String, Object>();
			  
			for(Map.Entry entry : uwords.entrySet())
			{
			  
				resultWords.put("Word", entry.getKey()); 
				resultWords.put("Count", entry.getValue()); 
				collection.insert(new BasicDBObject(resultWords));
			
			}
			
			int minKey = Collections.min(uwords.values()); 
			System.out.println("min"+minKey);
			int maxKey = Collections.max(uwords.values()); 
			System.out.println("max"+maxKey);
			
	} 
	}
}
